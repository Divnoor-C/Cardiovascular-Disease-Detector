""""
where the model and data analysis is computed and created
"""
from typing import Any, Optional
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, accuracy_score
from sklearn.tree import DecisionTreeClassifier
import seaborn as sns
import plotly.express as px


class DataAnalysis:
    """
    a class used for data analysis/computation using pandas datatframes before building the model

    Instance Attributes:
        - file: The file name to a CSV file for analysis
        - df: A pandas DataFrame containing the data for analysis

    Representation Invariants:
        - self.file != ""
        - self.df is not None and isinstance(self.df, pd.DataFrame)
    """
    file: str
    df: pd.DataFrame

    def __init__(self, file: str) -> None:
        """Initializes a new DataAnaylsis with the given file and df"""
        self.file = file
        self.df = pd.read_csv(file, sep=';')

    def quality_checker(self) -> tuple[int, int, int]:
        """Return the number of missing values, duplicate values and invalid rows in the dataset"""

        missing_values = self.df.isnull().sum().sum()

        duplicate_rows = self.df.duplicated().sum()

        invalid_rows = len(self.df[(self.df['age'] < 0) | (self.df['weight'] < 0) | (self.df['height'] < 0)])

        return missing_values, duplicate_rows, invalid_rows

    def handle_missing_data(self, strategy: str) -> None:
        """
        Handle missing data in the dataset

        Preconditions:
            - strategy in {'mean', 'median', 'mode'}
        """
        if strategy == 'mean':
            self.df.fillna(self.df.mean(), inplace=True)
        elif strategy == 'median':
            self.df.fillna(self.df.median(), inplace=True)
        else:
            self.df.fillna(self.df.mode().iloc[0], inplace=True)

    def handle_duplicate_rows(self) -> None:
        """Handle duplicate rows in the dataset, keeps the first occurence of each duplicated row
            and drops the rest"""
        self.df.drop_duplicates(inplace=True)

    def data_summary(self) -> pd.DataFrame:
        """Provide a summary of the dataset"""
        summary = self.df.describe(include='all')
        return summary

    def remove_outliers(self, cols: list[str]) -> None:
        """Remove outliers from specified columns"""
        for col in cols:
            lower_bound = self.df[col].quantile(0.025)
            upper_bound = self.df[col].quantile(0.975)
            self.df = self.df[(self.df[col] >= lower_bound) & (self.df[col] <= upper_bound)]

    def correlation_heatmap(self) -> None:
        """Create a heatmap to showcase the correlation between variables"""
        corr_matrix = self.df.corr()
        sns.heatmap(corr_matrix, annot=True, cmap='viridis')

    def preprocess_data(self) -> None:
        """ makes the data suitable for model building"""

        self.df.drop('id', axis=1, inplace=True)
        self.df['bmi'] = (self.df['weight'] / ((self.df['height'] / 100) ** 2)).round()
        self.df['age'] = (self.df['age'] / 365).round()
        self.df['gender'] = self.df['gender'].map({1: 0, 2: 1})
        self.df.rename(columns={'ap_hi': 'systolic bp', 'ap_lo': 'diastolic bp'}, inplace=True)

    def visualize_data_numeric(self) -> None:
        """
        makes a visualization to showcase the relationship between numerical columns and target column

        Note: *used for testing purposes only*
        """

        numerical_cols = self.df.select_dtypes(include=['float64', 'int64']).columns
        numerical_cols = numerical_cols.drop(['cardio', 'smoke', 'cholesterol', 'alco', 'gluc', 'id', 'active'])
        for col in numerical_cols:
            fig = px.box(self.df, x='cardio', y=self.df[col])
            fig.update_layout(title=f'{col} vs Cardio', xaxis_title='Cardio', yaxis_title=col)
            fig.show()

    def average_cardio_stats(self, cols: list) -> tuple[dict, dict, dict, dict]:
        """Return the average of numerical values for males/females with and without cardiovascular disease"""
        male_avg_with_cardio = {}
        male_avg_without_cardio = {}
        female_avg_with_cardio = {}
        female_avg_without_cardio = {}

        for col in cols:
            male_avg_with_cardio[col] = self.df[(self.df['gender'] == 1) & (self.df['cardio'] == 1)][col].mean()
            male_avg_without_cardio[col] = self.df[(self.df['gender'] == 1) & (self.df['cardio'] == 0)][col].mean()
            female_avg_with_cardio[col] = self.df[(self.df['gender'] == 0) & (self.df['cardio'] == 1)][col].mean()
            female_avg_without_cardio[col] = self.df[(self.df['gender'] == 0) & (self.df['cardio'] == 0)][col].mean()

        return male_avg_with_cardio, male_avg_without_cardio, female_avg_with_cardio, female_avg_without_cardio

    def analyze_data_for_gender(self, user_inputs: dict, cat: str) -> tuple:
        """
        Analyze the data based on user inputs for gender and a specific category.

        This method calculates the number of individuals with cardiovascular disease
        (cardio = 1) and without cardiovascular disease (cardio = 0) for the given category
        (e.g., age, weight). It returns a tuple containing the counts
        for males and females with and without cardiovascular disease above, below, and equal to
        the user-response in the specified category.

        """
        gender = user_inputs['gender']
        if gender == "Male":
            gender_code = 1
        else:
            gender_code = 0

        gender_df = self.df[self.df['gender'] == gender_code]
        above_with_cardio = len(gender_df[(gender_df['cardio'] == 1) & (gender_df[cat] > int(user_inputs[cat]))])
        below_with_cardio = len(gender_df[(gender_df['cardio'] == 1) & (gender_df[cat] < int(user_inputs[cat]))])
        equal_with_cardio = len(gender_df[(gender_df['cardio'] == 1) & (gender_df[cat] == int(user_inputs[cat]))])
        above_without_cardio = len(gender_df[(gender_df['cardio'] == 0) & (gender_df[cat] > int(user_inputs[cat]))])
        below_without_cardio = len(gender_df[(gender_df['cardio'] == 0) & (gender_df[cat] < int(user_inputs[cat]))])
        equal_without_cardio = len(gender_df[(gender_df['cardio'] == 0) & (gender_df[cat] == int(user_inputs[cat]))])

        return (above_with_cardio, below_with_cardio, equal_with_cardio, above_without_cardio, below_without_cardio,
                equal_without_cardio)

# IMPORTANT: used for testing purposes
# f = DataAnalysis('cardio_train.csv')
# f.preprocess_data()
# f.remove_outliers(['weight', 'height'])
# f.correlation_heatmap()
# f.remove_outliers(['weight', 'height'])
# f.visualize_data_numeric()


class PredictionModel:
    """
    a class used to build the classification tree model

    Instance Attributes:
        - input_cols: The list of column names used as input features for the model.
        - target_col: The list of column names used as target labels for the model.
        - df: The pandas DataFrame containing the data for model building.
        - model: The classification model object. Initially set to None since there is no model.

    Representation Invariants:
        - self.input_cols != [].
        - self.target_col != []
        - self.df is not None.
    """

    input_cols: list[str]
    target_col: list[str]
    df: pd.DataFrame
    model: Optional[DecisionTreeClassifier] = None

    def __init__(self, input_cols: list[str], target_col: list[str], df: pd.DataFrame) -> None:
        """
        Initializes a new PredicitionModel with the given input_cols, target_col, df, and model
        """

        self.input_cols = input_cols
        self.target_col = target_col
        self.df = df
        self.model = None

    def split_data(self, test_size: float = 0.2, random_state: int = 56) -> tuple[Any, Any, Any, Any, Any, Any]:
        """Splits the data into train, validation, and test sets"""
        x = self.df[self.input_cols]
        y = self.df[self.target_col]

        x_train_val, x_test, y_train_val, y_test = train_test_split(x, y, test_size=test_size,
                                                                    random_state=random_state)

        x_train, x_val, y_train, y_val = train_test_split(x_train_val, y_train_val, test_size=0.25,
                                                          random_state=random_state)

        return x_train, x_val, x_test, y_train, y_val, y_test

    def train_validate_evaluate(self, max_depth: int = 8) -> tuple[float, float, float, Any, dict[str, str]]:
        """
        Train and validate the model, return the validation accuracy, test set accuracy, training accuracy,
        cross-validation scores, and classification report for the training set.

        To view a better version of the classfication report, uncomment the lines down below

        """
        x_train, x_val, x_test, y_train, y_val, y_test = self.split_data(test_size=0.2, random_state=65)

        # where the model is actually getting built and self.model is getting initialized
        self.model = DecisionTreeClassifier(max_depth=max_depth, random_state=65)
        self.model.fit(x_train, y_train)

        y_pred_val = self.model.predict(x_val)
        accuracy_val = accuracy_score(y_val, y_pred_val)

        y_pred_train = self.model.predict(x_train)  # Predict on the training set
        accuracy_train = accuracy_score(y_train, y_pred_train)

        y_pred_test = self.model.predict(x_test)
        accuracy_test = accuracy_score(y_test, y_pred_test)

        # IMPORTANT: USED FOR TESTING
        # # Perform cross-validation on the training set
        cv_scores = cross_val_score(self.model, x_train, y_train, cv=5)
        # print("Cross-validation scores:", cv_scores)
        # print("Mean CV accuracy:", cv_scores.mean())
        # print("Standard deviation of CV accuracy:", cv_scores.std())

        # Print classification report for training set, for more clear report, uncomment the following code
        # print("Classification report for training set:")
        # print(classification_report(y_train, self.model.predict(x_train)))
        class_report = (classification_report(y_train, self.model.predict(x_train)))

        return accuracy_val, accuracy_test, accuracy_train, cv_scores, class_report

    def feature_importance(self) -> None:
        """
        Prints the feature importance of the trained model.

        Preconditions:
            - self.model is not None
        """
        feature_importance = self.model.feature_importances_
        sorted_ids = feature_importance.argsort()

        for i in sorted_ids:
            print(f"{self.input_cols[i]}: {feature_importance[i]}")

    def make_prediction(self, input_data: list) -> str:
        """
        Returns a string that makes a prediction based off of the model of
        whether you have cardio-vasular disease or not.

        Preconditions:
            - self.model is not None
        """
        columns = self.input_cols
        df_input = pd.DataFrame([input_data], columns=columns)
        predictions = self.model.predict(df_input)
        if predictions == [1]:
            return 'According to our model, you may have cardio-vasular disease'
        else:
            return 'According to our model, you likely do not have cardio-vascular disease'

    def probability_of_prediction(self, input_data: list) -> float:
        """
        Predicts the probability of having cardiovascular disease based on the input data

        Preconditions:
            - self.model is not None
        """
        columns = self.input_cols
        df_input = pd.DataFrame([input_data], columns=columns)
        probability = self.model.predict_proba(df_input)[0][1]  # probability of 1 (getting cardiovascular disease)

        return probability * 100

    def find_best_depth(self, max_depth_range: int) -> tuple[int, float]:
        """Find the best depth for the decision tree model"""

        x_train, x_val, dummy1, y_train, y_val, dummy2 = self.split_data()

        best_depth = None
        best_accuracy = 0.0

        for depth in range(max_depth_range):
            model = DecisionTreeClassifier(max_depth=depth, random_state=56)
            model.fit(x_train, y_train)

            y_pred_val = model.predict(x_val)
            accuracy_val = accuracy_score(y_val, y_pred_val)

            if accuracy_val > best_accuracy:
                best_depth = depth
                best_accuracy = accuracy_val

        return best_depth, best_accuracy

    def max_depth_errors(self, max_depths: int) -> list[dict[str, float]]:
        """Calculate training and validation errors for different max_depth values."""
        errors = []
        for depth in range(1, max_depths):
            x_train, x_val, dummy1, y_train, y_val, dummy2 = self.split_data()

            model = DecisionTreeClassifier(max_depth=depth, random_state=56)
            model.fit(x_train, y_train)

            train_error = 1 - model.score(x_train, y_train)
            val_error = 1 - model.score(x_val, y_val)

            errors.append({'Max Depth': depth, 'Training Error': train_error, 'Validation Error': val_error})
        return errors


if __name__ == '__main__':
    # We have provided the following code to run any doctest examples that you add.
    # (We have not provided any doctest examples in the starter code, but encourage you
    # to add your own.)
    import doctest

    doctest.testmod(verbose=True)

    # When you are ready to check your work with python_ta, uncomment the following lines.
    # (In PyCharm, select the lines below and press Ctrl/Cmd + / to toggle comments.)
    import python_ta
    python_ta.check_all(config={
        'max-line-length': 120,
        'extra-imports': ['hashlib', 'pandas', 'sklearn', 'seaborn', 'sklearn.model_selection',
                          'sklearn.metrics', 'sklearn.tree', 'plotly.express'],
        'allowed-io': ['feature_importance']
    })
