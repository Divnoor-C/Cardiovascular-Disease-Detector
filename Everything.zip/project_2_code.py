""""
where the GUI is created, and where the results from the model is outputted
"""

from __future__ import annotations
import tkinter as tk
from tkinter import messagebox
from typing import Any
from model import PredictionModel, DataAnalysis


class QuestionnaireApp:
    """
    This class creates the questionaire in which the user will give the data needed to
    see if they have cardiovascular disease or not.

    Instance Attributes
        - root: the root of the window
        - file: the name of the CSV file
        = title_label: the title of the homepage
        - start_button: button to start the questionnaire
        - frame: frame for organizing widgets
        - current_question_index: index of the current question
        - questions: list of questions in the questionnaire
        - responses: dictionary to store user responses
        - result: string to store the result of the questionnaire
        - percentage: float to store the percentage of likelihood of cardiovascular disease
        - label: label widget for displaying text
        - checkbox_vars: list of IntVar for checkbox values
        - checkboxes: list of checkboxes
        - age_slider: Scale widget for selecting age
        - entry: Entry widget for user input
        - next_button: button for moving to the next question
        - submit_button: button for submitting the questionnaire
        - yes_button: button for answering "Yes"
        - no_button: button for answering "No"
        - agree_button: button for agreeing
        - disagree_button: button for disagreeing
        - male_button: button for selecting male gender
        - female_button: button for selecting female gender

    Representation Invariants
        - self.file!= ""
    """
    root: Any
    file: str
    title_label: tk.Label
    start_button: tk.Button
    frame: tk.Frame
    current_question_index: int
    questions: list[dict[str, list[str] | str] | dict[str, str] | dict[str, str] | dict[str, str] | dict[str, str]
                    | dict[str, str] | dict[str, str] | dict[str, str] | dict[str, str] | dict[str, str] | Any]
    responses: dict
    result: str
    percentage: float
    label: tk.Label
    checkbox_vars: list[tk.IntVar]
    checkboxes: list
    age_slider: tk.Scale
    entry: tk.Entry
    next_button: tk.Button
    submit_button: tk.Button
    yes_button: tk.Button
    no_button: tk.Button
    agree_button: tk.Button
    disagree_button: tk.Button
    male_button: tk.Button
    female_button: tk.Button

    def __init__(self, root: Any, file: str) -> None:
        """
         Initalizes the questionaire tree
        """
        self.root = root
        self.root.title("Questionnaire")
        self.file = file

        # Title Label
        self.title_label = tk.Label(root, text="Welcome to the CardioAlert", font=("Georgia", 20))
        self.title_label.pack(pady=(100, 20))  # Increased top padding and reduced bottom padding

        # Start Button
        self.start_button = tk.Button(root, text="Start", width=10, height=2, command=self.start_questionnaire,
                                      font=("Georgia", 12), cursor='hand2')
        self.start_button.pack(side="bottom", pady=200)  # Positioned at the bottom with some padding

    def start_questionnaire(self) -> None:
        """
        Creates the questionaire, by getting rid of start button and label
        """
        # Destroy the home page widgets
        self.title_label.destroy()
        self.start_button.destroy()

        # Initialize the questionnaire
        self.initialize_questionnaire()

    def initialize_questionnaire(self) -> None:
        """
        Intialize the syntax of the questionaire
        """
        self.frame = tk.Frame(self.root)  # Initialize the frame attribute
        self.frame.pack(padx=20, pady=20)
        self.root.title("Questionnaire")
        self.current_question_index = 0
        self.questions = [
            {"text": "Please carefully read the following terms and conditions:",
             "options": [
                 "This program is not an alternative to professional healthcare.",
                 "I consent to my participation in this survey.",
                 "I understand that my data will only be used for prediction-purposes.",
                 "I understand that none of my data will be stored once our prediction has been made.",
                 "I understand that this program does not take into consideration of underlying conditions, \n"
                 "such as diabetes, and as such, the prediction will be for the general population.",
                 "I have read all above terms and conditions."
             ],
             "type": "checkbox"},
            {"text": "Enter your age:", "type": "slider"},
            {"text": "Select your gender:", "type": "gender"},
            {"text": "Enter your height (cm):", "type": "text"},
            {"text": "Enter your weight (kg):", "type": "text"},
            {"text": "Enter your Systolic blood pressure (mm Hg):", "type": "text"},
            {"text": "Enter your Diastolic blood pressure (mm Hg):", "type": "text"},
            {"text": "Enter your Cholesterol level (1 for normal, 2 for above normal, 3 for well above normal:",
             "type": "text"},
            {"text": "Enter your Glucose level (1 for normal, 2 for above normal, 3 for well above normal:",
             "type": "text"},
            {"text": "Are you an active smoker?", "type": "yesno"},
            {"text": "Would you like to see your results? You will recieve a general prediction, \n"
                     " an estimated probability, and after, you'll be able to compare your results with the data \n"
                     " used to train the model visually on a new tab. \n"
                     "Once you exit from the results, the questionaire will close.", "type": "yesno"}
        ]
        self.responses = {}  # Dictionary to store responses
        self.result, self.percentage = "", 0
        self.label = tk.Label(self.frame, text=self.questions[self.current_question_index]["text"],
                              font=("Georgia", 12))
        self.label.pack(pady=20)
        self.checkbox_vars = []
        self.checkboxes = []
        self.show_buttons(["checkbox"])

        self.frame = tk.Frame(self.root)
        self.frame.pack(padx=20, pady=20)

        self.age_slider = tk.Scale(self.frame, from_=0, to=150, orient=tk.HORIZONTAL, length=300, font=("Georgia", 12),
                                   cursor='hand2')
        self.age_slider.grid(row=2, columnspan=2, pady=10)
        self.age_slider.grid_remove()
        self.entry = tk.Entry(self.frame, width=30)
        self.entry.grid(row=1, columnspan=2, pady=10)
        self.entry.grid_remove()  # Initially hide the entry widget
        self.next_button = self.create_button("Next", lambda: self.on_click("next"))
        self.submit_button = self.create_button("Submit", lambda: self.on_click("submit"))
        self.yes_button = self.create_button("Yes", lambda: self.on_click("yes"))
        self.no_button = self.create_button("No", lambda: self.on_click("no"))
        self.agree_button = self.create_button("I agree", lambda: self.on_click("yes"))
        self.disagree_button = self.create_button("I disagree", lambda: self.on_click("no"))
        self.male_button = self.create_button("Male", lambda: self.on_click("male"))
        self.female_button = self.create_button("Female", lambda: self.on_click("female"))
        self.show_buttons(["agree"])  # Show the Yes/No buttons by default

    def valid(self) -> bool:
        """
        Check whether the answer to the question is a valid response

        Preconditions:
            - self.questions[self.current_question_index]["type"] == "text":
        """
        response = self.entry.get().strip()  # Get the text entered by the user
        if self.current_question_index in [7, 8]:  # Check if the question asks for cholesterol or glucose level
            try:
                level = int(response)
                if level < 1 or level > 3:  # Cholesterol or glucose level should be between 1 and 3
                    messagebox.showerror("Error", "Level must be between 1 and 3.")
                    return False
                return True
            except ValueError:
                messagebox.showerror("Error", "Level must be a valid integer.")
                return False
        else:
            try:
                num = int(response)
                if num <= 0:
                    messagebox.showerror("Error", "Must be above 0.")
                    return False
            except ValueError:
                messagebox.showerror("Error", "Invalid input. Please enter a valid number.")
                return False
        return True

    def are_checkboxes_checked(self) -> bool:
        """
        Check if all checkboxes for the current question have been checked.
        """
        if self.questions[self.current_question_index]["type"] == "checkbox":
            for var in self.checkbox_vars:
                if var.get() == 0:
                    return False
            return True
        return True

    def on_yes_click(self) -> None:
        """
        Helper function to give the command on what happens when you click yes, used in on_click
        """

        if self.current_question_index == 0:
            if not self.are_checkboxes_checked():
                messagebox.showerror("Error", "Please check all checkboxes before proceeding.")
                return
            else:
                messagebox.showinfo("Response", "You may now proceed")
        elif self.questions[self.current_question_index]["type"] == "text":
            self.show_buttons(["submit"])  # Show the submit button for text-based questions
        elif self.questions[self.current_question_index]["type"] == "gender":
            self.responses[self.current_question_index] = "Female"  # Save the response
        else:
            if self.current_question_index not in {0, len(self.questions) - 1}:
                self.responses[self.current_question_index] = 1  # Save the response
            if self.current_question_index == len(self.questions) - 1:
                f = DataAnalysis('cardio_train.csv')
                f.preprocess_data()
                f.remove_outliers(['weight', 'height', 'systolic bp', 'diastolic bp'])
                d = PredictionModel(
                    ['age', 'gender', 'weight', 'systolic bp', 'diastolic bp', 'cholesterol', 'gluc', 'smoke',
                     'bmi'],
                    ['cardio'], f.df)
                d.train_validate_evaluate()
                self.get_responses()[10] = round(
                    (int(self.get_responses()[4]) / ((int(self.get_responses()[3]) / 100) ** 2)))
                self.result = d.make_prediction([self.get_responses()[x] for x in self.get_responses() if x != 2])
                self.percentage = d.probability_of_prediction(
                    [self.get_responses()[x] for x in self.get_responses() if x != 2])
                # Display the bar chart with three colors
                self.display_bar_chart()
                return  # Exit the method after displaying the bar chart

    def on_click(self, button: str) -> None:
        """
        This method handles the button clicks in the questionnaire.
        """
        if button == 'male':
            self.responses[self.current_question_index] = "Male"
        elif button == "female":
            self.responses[self.current_question_index] = "Female"
        elif button == "submit":
            if self.valid():
                response = self.entry.get().strip()
                self.responses[self.current_question_index] = response
            else:
                return
        elif button == "no":
            if self.current_question_index in {0, 10}:  # If it's the first question
                messagebox.showinfo("Response", "Exiting the questionnaire.")  # Show a message
                self.root.destroy()  # Exit the application
                self.current_question_index = -1
            else:
                self.responses[self.current_question_index] = 0  # Save the response
        elif button == "yes":
            self.on_yes_click()
        else:
            age = self.age_slider.get()
            self.responses[self.current_question_index] = age  # Save the response

        if 0 <= self.current_question_index < len(self.questions) - 1 and self.are_checkboxes_checked():
            self.next_question()  # Move to the next question

    def display_bar_chart(self) -> None:
        """
        Displays a horizontal bar with a color representing the probability of having cardiovascular disease.
        """
        # Define the probability and calculate the color gradient
        probability = self.percentage / 100  # Assuming percentage is already calculated
        # Define the color gradient from green to red
        red = int(255 * probability)
        green = int(255 * (1 - probability))
        blue = 0
        bar_color = f'#{red:02x}{green:02x}{blue:02x}'

        # Create a new Tkinter window
        bar_window = tk.Toplevel(self.root)
        bar_window.title("Probability of Having Cardiovascular Disease")

        # Add text above the bar
        text_label = tk.Label(bar_window, text=str(self.result + " \n with a estimated probability of:"),
                              font=("Arial", 12))
        text_label.pack()

        # Define the width and height of the canvas
        canvas_width = 400
        canvas_height = 50

        # Create a Canvas widget
        canvas = tk.Canvas(bar_window, width=canvas_width, height=canvas_height)
        canvas.pack()

        # Calculate the width of the bar based on the probability
        bar_width = probability * canvas_width

        # Draw the rectangle representing the bar
        canvas.create_rectangle(0, 0, bar_width, canvas_height, fill=bar_color)

        # Display the percentage text inside the bar
        percentage_text = f"{round(self.percentage, 2)}%"
        canvas.create_text(bar_width / 2, canvas_height / 2, text=percentage_text, fill='white', font=("Arial", 12))

        def on_bar_window_close() -> None:
            """
            Used to destory the root
            """
            self.root.destroy()

        bar_window.protocol("WM_DELETE_WINDOW", on_bar_window_close)

    def next_question(self) -> None:
        """
        Moves to the next question. And if there are more question it checks what type of question it is and displays
        what needs to be displaced depending on the type of question. If there are no more questions, it closes the
        window
        """
        self.current_question_index += 1  # Move to the next question
        if self.current_question_index < len(self.questions):  # If there are more questions
            self.label.config(text=self.questions[self.current_question_index]["text"])  # Update the label text
            if self.questions[self.current_question_index]["type"] == "text":  # If the next question is text-based
                # Show text entry and submit button
                self.show_buttons(['submit', 'entry'])
                self.entry.delete(0, tk.END)
                self.hide_buttons(["yes_no", "gender", "slider", "next", "checkbox"])

            elif self.questions[self.current_question_index]["type"] == "gender":  # If it's a gender question
                # Show gender buttons
                self.show_buttons(["gender"])
                self.hide_buttons(["yes_no", "submit", "agree", "slider", "next", "checkbox", "entry"])
            elif self.questions[self.current_question_index]["type"] == "slider":
                # Show slider, slider value label, and next button
                self.show_buttons(["slider", "next"])
                self.hide_buttons(["yes_no", "gender", "agree", "submit", "checkbox"])
            else:  # Show Yes/No buttons
                self.show_buttons(["yes_no"])
                self.hide_buttons(["slider", "next", "gender", "agree", "submit", "checkbox", "entry"])
        else:
            # Final message
            messagebox.showinfo("Final Response", self.result + " with a estimated probability of "
                                + str(round(self.percentage)) + "%")
            self.root.destroy()

    def create_button(self, text: str, command: Any) -> tk.Button:
        """
        Creates a button depending on the text (name) and the command (what happens when you click it).
        """
        button = tk.Button(self.frame, text=text, width=10, height=2, command=command,
                           font=("Georgia", 12), cursor='hand2')
        button.grid_remove()
        return button

    def show_questionnaire_window(self) -> None:
        """
        Displays the questionnaire window again when the bar chart window is closed.
        """
        self.root.deiconify()

    def show_buttons(self, buttons: list[str]) -> None:
        """
        Shows the button (multiple or single) which is in a list (so we can put multiple) within a specific row/column
        """
        for button in buttons:
            if button == "gender":
                self.female_button.grid(row=2, column=0, padx=10)
                self.male_button.grid(row=2, column=1, padx=10)
            elif button == "submit":
                self.submit_button.grid()  # Show the submit button
            elif button == "agree":
                self.agree_button.grid(row=2, column=0, padx=10)
                self.disagree_button.grid(row=2, column=1, padx=10)
            elif button == "slider":
                self.age_slider.grid(row=2)
            elif button == "next":
                self.next_button.grid()
            elif button == "checkbox":
                options = self.questions[self.current_question_index]["options"]
                for option in options:
                    var = tk.IntVar(value=0)  # Ensure each checkbox variable is initialized to 0
                    checkbox = tk.Checkbutton(self.frame, text=option, variable=var, font=("Georgia", 12))
                    checkbox.pack(anchor=tk.W)  # Pack the checkbox below the question label
                    self.checkbox_vars.append(var)
                    self.checkboxes.append(checkbox)
            elif button == "entry":
                self.entry.grid()
            else:
                self.yes_button.grid(row=2, column=0, padx=10)
                self.no_button.grid(row=2, column=1, padx=10)

    def hide_buttons(self, buttons: list[str]) -> None:
        """
        hides the button (multiple or single) which is in a list (so we can hide multiple)
        """
        for button in buttons:
            if button == "gender":
                self.male_button.grid_remove()
                self.female_button.grid_remove()
            elif button == "submit":
                self.submit_button.grid_remove()
            elif button == "agree":
                self.agree_button.grid_remove()
                self.disagree_button.grid_remove()
            elif button == "slider":
                self.age_slider.grid_remove()
            elif button == "next":
                self.next_button.grid_remove()
            elif button == "checkbox":
                for checkbox in self.checkboxes:
                    checkbox.pack_forget()
            elif button == "entry":
                self.entry.grid_remove()
            else:
                self.yes_button.grid_remove()
                self.no_button.grid_remove()

    def get_responses(self) -> dict[int, Any]:
        """
        return the responses given by user
        """
        return self.responses


if __name__ == "__main__":
    mainroot = tk.Tk()
    app = QuestionnaireApp(mainroot, "cardio_train.csv")
    mainroot.geometry('750x750')
    mainroot.mainloop()
    responses = app.get_responses()
    import doctest

    doctest.testmod(verbose=True)

    # When you are ready to check your work with python_ta, uncomment the following lines.
    # (In PyCharm, select the lines below and press Ctrl/Cmd + / to toggle comments.)
    import python_ta

    python_ta.check_all(config={
        'max-line-length': 120,
        'max_instance_attributes': 100,
        'extra-imports': ['hashlib', 'tkinter', 'typing', 'model'],
        'allowed-io': ['feature_importance']
    })
