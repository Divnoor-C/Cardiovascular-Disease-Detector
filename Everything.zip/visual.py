"""
code to run our visualizations
"""
from typing import Any
import tkinter as tk
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from project_2_code import QuestionnaireApp
from model import DataAnalysis


class DataVisualizer:
    """
    class used for outputting visual metrics of user

    Instance Attributes:
        - appp: An instance of the Questionaire class used to obtain and store the user's responses
        - calculator: An instance of the DataAnalysis class used for calculations

    Representation Invariants:
    - isinstance(self.appp, QuestionaireApp)
    - isinstance(self.calculator, calculator)
    """
    appp: QuestionnaireApp
    calculator: DataAnalysis

    def __init__(self, appp: QuestionnaireApp) -> None:
        """Initializes a new DataVisualizer with the given application and calculator."""
        self.appp = appp
        self.calculator = DataAnalysis("cardio_train.csv")

    def get_responses(self) -> dict[int, Any]:
        """
        gets the responses of the user
        """
        return self.appp.get_responses()

    def create_bar_graph(self, response: dict[int, Any]) -> None:
        """Create a bar graph comparing the user's stats with average stats."""
        self.calculator.preprocess_data()
        male_avg_with_cardio, male_avg_without_cardio, female_avg_with_cardio, female_avg_without_cardio = (
            self.calculator.average_cardio_stats(['age', 'height', 'weight', 'systolic bp', 'diastolic bp', 'bmi']))
        male_avg_with_cardio1, male_avg_without_cardio1, female_avg_with_cardio1, female_avg_without_cardio1 = (
            self.calculator.average_cardio_stats(['cholesterol', 'gluc']))

        if response[2] == 'Male':
            user_avg_1 = male_avg_with_cardio
            user_avg_2 = male_avg_with_cardio1
            user_avg_3 = male_avg_without_cardio
            user_avg_4 = male_avg_without_cardio1
        else:
            user_avg_1, user_avg_2 = female_avg_with_cardio, female_avg_with_cardio1
            user_avg_3, user_avg_4 = female_avg_without_cardio, female_avg_without_cardio1

        # Create a bar graph
        fig = make_subplots(rows=1, cols=2, subplot_titles=("Average Stats with True Numerical values",
                                                            "Average Stats with Binary Values"))

        # Add traces for the first subplot
        fig.add_trace(go.Bar(name='Average Cardiovascular Patient', x=list(user_avg_1.keys()), y=[user_avg_1[k]
                      for k in user_avg_1]), row=1, col=1)
        fig.add_trace(go.Bar(name='User', x=list(user_avg_1), y=[int(response[k])
                      for k in response.keys() if k not in {2, 7, 8, 9}]), row=1, col=1)
        fig.add_trace(go.Bar(name='Average Non Cardiovascular Patient', x=list(user_avg_3),
                      y=[user_avg_3[k] for k in user_avg_3]), row=1, col=1)

        # Add traces for the second subplot
        fig.add_trace(go.Bar(name='Average Cardiovascular Patient', x=list(user_avg_2), y=[user_avg_2[k]
                      for k in user_avg_2]), row=1, col=2)

        fig.add_trace(go.Bar(name='User', x=list(user_avg_2), y=[int(response[k])
                      for k in response.keys() if k >= 7]), row=1, col=2)

        fig.add_trace(go.Bar(name='Average Non Cardiovascular Patient', x=list(user_avg_2),
                      y=[user_avg_4[k] for k in user_avg_4]), row=1, col=2)

        # Update layout
        fig.update_layout(barmode='group', title_text="Comparison of Average Stats with User's Stats")
        fig.show()

    def create_pie_charts(self, response: dict) -> None:
        """Create pie charts for categories based on user's responses."""
        fig2 = make_subplots(rows=5, cols=2, specs=[[{'type': 'domain'}] * 2] * 5)

        labels = ['Above with Cardio', 'Below with Cardio', 'Equal with Cardio', 'Above without Cardio',
                  'Below without Cardio', 'Equal without Cardio']

        cat = ['age', 'gender', 'height', 'weight', 'systolic bp', 'diastolic bp', 'cholesterol', 'gluc', 'bmi']
        color_palette = ['red', 'green', 'blue', 'purple', 'orange', 'pink']

        responses1 = {}

        for x in range(1, len(cat) + 1):
            responses1[cat[x - 1]] = response[x]
        for i in range(len(cat)):
            if cat[i] != 'gender':

                data = self.calculator.analyze_data_for_gender(responses1, cat[i])
                category_name = cat[i]
                row_num = i // 2 + 1
                col_num = i % 2 + 1

                # Add trace to the subplot
                fig2.add_trace(go.Pie(labels=labels, values=data, name=category_name,
                                      marker_colors=color_palette),
                               row=row_num, col=col_num)
                fig2.update_xaxes(title_text=category_name, row=row_num, col=col_num)
                fig2.update_yaxes(title_text="Count", row=row_num, col=col_num)

            fig2.update_layout(title="Pie Charts for Categories", showlegend=True,
                               legend={"x": 0.75, "y": 1, "xanchor": 'right', "yanchor": 'top'})

            fig2.update_layout(
                autosize=False,
                width=1750,
                height=1750
            )

        fig2.show()


if __name__ == "__main__":
    mainroot = tk.Tk()
    app = QuestionnaireApp(mainroot, "cardio_train.csv")
    mainroot.geometry('750x750')
    mainroot.mainloop()
    responses = app.get_responses()
    import doctest

    doctest.testmod(verbose=True)

    # When you are ready to check your work with python_ta, uncomment the following lines.
    # (In PyCharm, select the lines below and press Ctrl/Cmd + / to toggle comments.)
    import python_ta

    python_ta.check_all(config={
        'max-line-length': 120,
        'max_instance_attributes': 100,
        'extra-imports': ['hashlib', 'plotly.graph_objects', 'plotly.subplots', 'model', "tkinter", 'project_2_code'],
        'allowed-io': ['feature_importance']
    })
